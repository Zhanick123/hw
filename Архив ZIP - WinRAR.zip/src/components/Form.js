import { useState } from "react";
import Input from "../components/Inputs/input";
import '../components/app/app.css'

export default function Form( {}){
return (
   <div></div>
    )
}